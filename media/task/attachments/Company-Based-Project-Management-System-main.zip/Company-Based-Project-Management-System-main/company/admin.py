from django.contrib import admin
from .models import Department, Position, Benefit

admin.site.register(Department)
admin.site.register(Position)
admin.site.register(Benefit)
